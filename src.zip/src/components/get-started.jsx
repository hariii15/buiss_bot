import React from 'react'

const started = () => {
  return (
    <div>started</div>
  )
}

export default started
